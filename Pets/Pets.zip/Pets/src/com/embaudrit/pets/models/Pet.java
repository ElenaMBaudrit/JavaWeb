package com.embaudrit.pets.models;

public interface Pet {
	String showAffection();
}
